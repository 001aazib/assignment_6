This repo contains the exact solution of Assignment 06.
